// cmMod.hpp (C)
#pragma once

#error "cmMod.hpp in incC must not be included"
