#pragma once

#include <string>

std::string getStrCpyTest();
