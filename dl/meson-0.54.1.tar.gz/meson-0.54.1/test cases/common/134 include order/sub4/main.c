/* Use the <> include notation to force searching in include directories */
#include <main.h>

int main(void) {
  if (somefunc() == 1984)
    return 0;
  return 1;
}
