#!/usr/bin/env python3
import sys

with open(sys.argv[1], 'w') as f:
    print('# this file does nothing', file=f)
