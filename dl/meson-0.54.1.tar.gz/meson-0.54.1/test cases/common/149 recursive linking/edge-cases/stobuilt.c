#include "../lib.h"


SYMBOL_EXPORT
int get_builto_value (void) {
  return 1;
}
