int get_st1_prop (void) {
  return 1;
}
